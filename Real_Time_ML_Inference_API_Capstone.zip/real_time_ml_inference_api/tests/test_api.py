from fastapi.testclient import TestClient
from app.main import app, FEATURE_NAMES

client = TestClient(app)

# Representative numeric values from the dataset; tests the API contract, not a clinical result.
SAMPLE = {
    "mean radius": 14.0, "mean texture": 20.0, "mean perimeter": 90.0,
    "mean area": 600.0, "mean smoothness": 0.10, "mean compactness": 0.10,
    "mean concavity": 0.08, "mean concave points": 0.05, "mean symmetry": 0.18,
    "mean fractal dimension": 0.06, "radius error": 0.3, "texture error": 1.0,
    "perimeter error": 2.0, "area error": 25.0, "smoothness error": 0.007,
    "compactness error": 0.02, "concavity error": 0.02, "concave points error": 0.01,
    "symmetry error": 0.02, "fractal dimension error": 0.003, "worst radius": 16.0,
    "worst texture": 25.0, "worst perimeter": 105.0, "worst area": 800.0,
    "worst smoothness": 0.14, "worst compactness": 0.25, "worst concavity": 0.25,
    "worst concave points": 0.10, "worst symmetry": 0.30, "worst fractal dimension": 0.08,
}

def test_health():
    response = client.get('/health')
    assert response.status_code == 200
    assert response.json()['model_loaded'] is True

def test_schema_has_30_features():
    response = client.get('/schema')
    assert response.status_code == 200
    assert response.json()['feature_count'] == 30

def test_prediction_schema_and_probabilities():
    response = client.post('/predict', json={'features': SAMPLE})
    assert response.status_code == 200
    data = response.json()
    assert data['label'] in {'benign', 'malignant'}
    assert data['prediction'] in {0, 1}
    assert set(data['probabilities']) == {'benign', 'malignant'}
    assert abs(sum(data['probabilities'].values()) - 1.0) < 1e-6
    assert data['model_name']

def test_missing_feature_returns_422():
    sample = dict(SAMPLE)
    sample.pop(FEATURE_NAMES[0])
    response = client.post('/predict', json={'features': sample})
    assert response.status_code == 422

def test_extra_feature_returns_422():
    sample = dict(SAMPLE)
    sample['not_a_real_feature'] = 1.0
    response = client.post('/predict', json={'features': sample})
    assert response.status_code == 422
