from pathlib import Path
from typing import Dict, List
import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
MODEL_PATH = ROOT / "models" / "champion_model.joblib"
model = joblib.load(MODEL_PATH)
FEATURE_NAMES: List[str] = list(model.feature_names_in_)
CLASS_NAMES = {0: "malignant", 1: "benign"}

app = FastAPI(
    title="Real-Time ML Inference API",
    version="1.0.0",
    description=(
        "REST API serving a trained Logistic Regression pipeline for the "
        "Breast Cancer Wisconsin Diagnostic dataset. This is an educational "
        "demo, not a medical diagnostic device."
    ),
)

class PredictionRequest(BaseModel):
    features: Dict[str, float] = Field(
        ..., description="Object containing all 30 numeric model features by their exact feature names."
    )

class PredictionResponse(BaseModel):
    prediction: int
    label: str
    probabilities: Dict[str, float]
    model_name: str

@app.get("/", tags=["Health"])
def root():
    return {"service": "Real-Time ML Inference API", "status": "ok", "docs": "/docs"}

@app.get("/health", tags=["Health"])
def health():
    return {"status": "healthy", "model_loaded": model is not None}

@app.get("/schema", tags=["Model"])
def schema():
    return {"required_features": FEATURE_NAMES, "feature_count": len(FEATURE_NAMES)}

@app.post("/predict", response_model=PredictionResponse, tags=["Prediction"])
def predict(payload: PredictionRequest):
    supplied = set(payload.features.keys())
    required = set(FEATURE_NAMES)
    missing = sorted(required - supplied)
    extra = sorted(supplied - required)
    if missing or extra:
        raise HTTPException(
            status_code=422,
            detail={"message": "Feature names do not match the trained model.", "missing_features": missing, "unexpected_features": extra},
        )
    values = [payload.features[name] for name in FEATURE_NAMES]
    if not np.all(np.isfinite(np.asarray(values, dtype=float))):
        raise HTTPException(status_code=422, detail="All feature values must be finite numbers.")
    row = pd.DataFrame([[float(payload.features[name]) for name in FEATURE_NAMES]], columns=FEATURE_NAMES)
    probabilities_array = model.predict_proba(row)[0]
    prediction = int(model.predict(row)[0])
    probabilities = {CLASS_NAMES[int(cls)]: float(prob) for cls, prob in zip(model.classes_, probabilities_array)}
    return PredictionResponse(
        prediction=prediction,
        label=CLASS_NAMES[prediction],
        probabilities=probabilities,
        model_name="LogisticRegression champion pipeline",
    )
